# JARVIS Mobile 2.0 – KI + Stimme (iPhone / iPad)

## Das funktioniert
- Echtes KI-Chatten über eine Netlify-Serverfunktion und die OpenAI-API
- Zugangscode vor KI-Anfragen (einfacher Schutz, keine vollwertige Anmeldung)
- Vorlesen von Antworten über die Sprachausgabe des Geräts (Button „Stimme: An“)
- Spracheingabe über Browser, wenn unterstützt; sonst das Mikrofon der iPad-/iPhone-Tastatur
- Aufgaben und Notizen nur lokal auf dem jeweiligen Gerät
- PWA-Installation über Safari → Teilen → Zum Home-Bildschirm

## Noch NICHT enthalten
- Keine Shopify-/Gmail-Verbindung, keine Automationen, keine Synchronisierung zwischen Geräten
- Keine Benutzerkonten, keine strenge Rate-Limitierung, keine vollständige Produktionssicherheit
- Die OpenAI-API ist separat kostenpflichtig; ChatGPT Plus ist kein API-Guthaben

## WICHTIG: Nicht mit Netlify Drop bereitstellen
Diese Version hat eine Serverfunktion in `netlify/functions/chat.mjs`. Netlify Drop (einfacher Ordnerupload) stellt solche Funktionen nicht zuverlässig bereit. **Nutze GitHub + Netlify „Import an existing project“.**

## Einrichtung nur auf iPad / iPhone
1. Erstelle auf https://github.com ein **privates** Repository, z. B. `jarvis-mobile-2`.
2. Lade alle Dateien **mit Ordnerstruktur** in dieses Repository: `index.html`, `manifest.webmanifest`, `sw.js`, `icon-192.png`, `icon-512.png`, `netlify.toml`, `netlify/functions/chat.mjs`. Auf iPad kann GitHubs Web-Oberfläche unter „Add file → Upload files“ verwendet werden; für Unterordner ggf. die Datei `netlify/functions/chat.mjs` über „Add file → Create new file“ mit genau diesem Pfad anlegen und Inhalt aus der mitgelieferten Datei einfügen. Alternativ ein GitHub-kompatibles iPad-Git-Programm verwenden.
3. Öffne https://app.netlify.com → „Add new project“ → „Import an existing project“ → GitHub → wähle das Repository. Veröffentlichungsordner: `.` (Punkt); Netlify erkennt `netlify.toml`. Starte den Deploy.
4. Erstelle unter https://platform.openai.com/api-keys einen OpenAI-API-Schlüssel und richte ggf. API-Abrechnung/Budget ein. **Niemals** Schlüssel in GitHub, HTML oder Chat posten.
5. Netlify → deine Site → „Project configuration“ / „Environment variables“: `OPENAI_API_KEY` = geheimer API-Schlüssel; `JARVIS_ACCESS_CODE` = selbst gewählter langer, zufälliger Zugangscode; optional `OPENAI_MODEL` = `gpt-4o-mini`. Variablen für Serverfunktionen verfügbar machen, dann **Deploy erneut starten**.
6. Öffne die neue `https://...netlify.app`-Adresse in Safari, trage den Zugangscode ein und teste „Hallo Jarvis“.
7. Safari → Teilen → Zum Home-Bildschirm → Hinzufügen. Auf dem iPhone mit derselben URL wiederholen. **Die Daten werden noch nicht synchronisiert.**
8. Die bisherige Netlify-Demo bleibt unverändert, bis du sie bewusst ersetzt. Installiere die neue URL zusätzlich und entferne die alte Verknüpfung bei Bedarf.

## Sicherheitsgrenzen
Ein Zugangscode in der App ist kein vollwertiger Schutz vor Angriffen auf einen öffentlich erreichbaren API-Endpunkt. Für produktiven Betrieb Authentifizierung, serverseitige Ratenbegrenzung, Monitoring, Ausgabenlimits und Zugriffskontrolle ergänzen. Keine vertraulichen Dokumente hochladen. Nie den API-Schlüssel in die PWA eingeben.
