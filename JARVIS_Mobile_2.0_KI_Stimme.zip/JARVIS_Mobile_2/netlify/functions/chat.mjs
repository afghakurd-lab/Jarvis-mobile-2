export default async (request) => {
 const headers={'Content-Type':'application/json','Cache-Control':'no-store'};
 const reply=(code,msg)=>new Response(JSON.stringify({error:msg}),{status:code,headers});
 if(request.method!=='POST')return reply(405,'Nur POST erlaubt');
 if(!process.env.OPENAI_API_KEY || !process.env.JARVIS_ACCESS_CODE)return reply(503,'Server noch nicht eingerichtet: OPENAI_API_KEY und JARVIS_ACCESS_CODE fehlen.');
 let payload;try{payload=await request.json()}catch{return reply(400,'Ungültige Anfrage')}
 if(typeof payload.code!=='string'||payload.code!==process.env.JARVIS_ACCESS_CODE)return reply(401,'Zugangscode falsch');
 const messages=Array.isArray(payload.messages)?payload.messages.slice(-12):[];
 const clean=messages.filter(m=>['user','assistant'].includes(m.role)&&typeof m.content==='string').map(m=>({role:m.role,content:m.content.slice(0,3000)}));
 if(!clean.length)return reply(400,'Keine Nachricht');
 try{
 const response=await fetch('https://api.openai.com/v1/chat/completions',{method:'POST',headers:{'Authorization':`Bearer ${process.env.OPENAI_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({model:process.env.OPENAI_MODEL||'gpt-4o-mini',max_tokens:450,messages:[{role:'system',content:'Du bist JARVIS, ein hilfreicher deutschsprachiger persönlicher Assistent. Antworte klar und kurz. Behaupte niemals, Shopify, Gmail, Konten oder private Dateien lesen oder Aktionen ausführen zu können: Diese Integrationen sind nicht verbunden. Gib keine Geheimnisse preis. Frage vor jeder externen Aktion um Freigabe.'},...clean]})});
 const result=await response.json();if(!response.ok)return reply(502,'KI-Anfrage fehlgeschlagen. Prüfe API-Guthaben und Modell.');
 return new Response(JSON.stringify({answer:result.choices?.[0]?.message?.content||'Keine Antwort erhalten.'}),{status:200,headers});
 }catch{return reply(502,'Verbindung zum KI-Dienst fehlgeschlagen')}
};
export const config={path:'/api/chat'};
